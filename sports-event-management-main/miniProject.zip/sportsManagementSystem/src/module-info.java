/**
 * 
 */
/**
 * @author Lenovo
 *
 */
module sportsManagementSystem {
	requires java.desktop;
	requires java.sql;
}